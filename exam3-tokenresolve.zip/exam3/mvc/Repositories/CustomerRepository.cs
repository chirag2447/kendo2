using Npgsql;
using Repository.Models;

namespace mvc.Repositories;
public class CustomerRepository
{
    private string conn;
    private IHttpContextAccessor access;

    public CustomerRepository(IConfiguration config, IHttpContextAccessor acc)
    {
        conn = config.GetConnectionString("a");
        access = acc;
    }

    public int AddToken(CustomerTokenModel token)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "insert into t_customer_token(c_token_type,c_status) values(@t,'Pending') returning c_token_id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@t", token.c_token_type);
                var id = comm.ExecuteScalar();
                return Convert.ToInt32(id);
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return 0;
    }

    public List<CustomerTokenModel> GetAllTokens()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_token_id,c_token_type,c_status from t_customer_token where c_status='Pending'";
                var comm = new NpgsqlCommand(query, con);
                var reader = comm.ExecuteReader();
                var tokens = new List<CustomerTokenModel>();
                while (reader.Read())
                {
                    var token = new CustomerTokenModel
                    {
                        c_token_id = reader.GetInt32(0),
                        c_token_type = reader.GetString(1),
                        c_status = reader.GetString(2)
                    };
                    tokens.Add(token);
                }
                return tokens;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }
}