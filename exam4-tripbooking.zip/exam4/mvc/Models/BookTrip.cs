namespace mvc.Models
{
    public class BookTrip
    {
        //c_id,c_trip,c_date,c_price,c_available_tickets,c_quantity,c_cost,c_status
        public int? c_id { get; set; }
        public string c_trip { get; set; }
        public DateTime c_date { get; set; }
        public string c_price { get; set; }

        public int? c_available_tickets { get; set; }
        public int? c_quantity { get; set; }
        public int c_cost { get; set; }
        public string? c_status { get; set; }
        public int? c_user_id { get; set; }
        public string? c_trip_name { get; set; }

    }
}