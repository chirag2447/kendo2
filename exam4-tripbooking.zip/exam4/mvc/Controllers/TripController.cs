using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class TripController : Controller
{
    private readonly TripRepository repo;

    public TripController(TripRepository re)
    {
        repo = re;
    }

    public IActionResult Index()
    {

        return View();
    }

    public IActionResult GetTrips()
    {
        var trips = repo.GetTrips();
        return Ok(trips);
    }

    public IActionResult CreateTrip(TripModel trip)
    {
        repo.AddTrip(trip);
        return Ok();
    }

    public IActionResult UpdateTrip(TripModel trip)
    {
        repo.UpdateTrip(trip);
        return Ok();
    }

    [HttpGet]
    public IActionResult DeleteTrip(int id)
    {
        repo.DeleteTrip(id);
        return Ok();
    }

    [HttpPost]
    public IActionResult DeleteTrips(List<int> ids)
    {
        repo.DeleteTrips(ids);
        return Ok();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
