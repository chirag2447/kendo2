using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class UserController : Controller
{
    private readonly TripRepository trepo;
    private readonly UserRepository urepo;

    public UserController(TripRepository tr, UserRepository ur)
    {
        trepo = tr;
        urepo = ur;
    }


    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Login(UserModel user)
    {
        if (urepo.Login(user))
        {
            return RedirectToAction("index");
        }
        else
        {
            return View();
        }
    }

    public IActionResult Index()
    {
        var trips = urepo.GetUserTrips();
        return View(trips);
    }

    public IActionResult Book()
    {
        var trips = trepo.GetTrips();
        ViewBag.trip = trips;
        return View();
    }

    [HttpPost]
    public IActionResult Book(BookTrip book)
    {
        urepo.Book(book);
        return RedirectToAction("index");
    }

    public IActionResult GetTrip(int id)
    {
        var trip = trepo.GetTripById(id);
        return Ok(trip);
    }

    public IActionResult CancelTrip(int id)
    {
        urepo.CancelTrip(id);
        return RedirectToAction("index");
    }

    public IActionResult GetHistory()
    {
        var trips = urepo.GetBookingHistory();
        return View(trips);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
