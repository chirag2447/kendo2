using mvc.Models;
using Npgsql;

namespace mvc.Repositories;
public class UserRepository
{
    private string conn;
    private IHttpContextAccessor access;
    public UserRepository(IConfiguration config, IHttpContextAccessor acc)
    {
        conn = config.GetConnectionString("a");
        access = acc;
    }

    public bool Login(UserModel user)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {


                con.Open();
                string query = "select c_id, c_username, c_email, c_password, c_role from public.t_usermaster where c_email = @email and c_password=@pass";
                var command = new NpgsqlCommand(query, con);
                command.Parameters.AddWithValue("@email", user.c_email);
                command.Parameters.AddWithValue("@pass", user.c_password);
                // command.Parameters.AddWithValue("@password", user.c_password);

                var rows = command.ExecuteReader();
                if (rows.Read())
                {



                    string username = rows["c_username"].ToString();
                    string role = rows["c_role"].ToString();
                    access.HttpContext.Session.SetInt32("userid", rows.GetInt32(0));
                    access.HttpContext.Session.SetString("userrole", role);
                    access.HttpContext.Session.SetString("useremail", user.c_email);
                    access.HttpContext.Session.SetString("username", username);

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);

        }

        return false;
    }

    public void Book(BookTrip bookTrip)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                string trip = "";
                con.Open();
                var query = "select c_trip from t_trip where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", Convert.ToInt32(bookTrip.c_trip));
                using (var reader = comm.ExecuteReader())
                {

                    if (reader.Read())
                    {

                        trip = reader.GetString(0);
                    }
                };
                var query1 = "insert into public.t_book_trip(c_trip,c_date,c_price,c_available_tickets,c_quantity,c_cost,c_status,c_user_id) values(@t,@d,@p,@at,@q,@c,@s,@u)";
                comm = new NpgsqlCommand(query1, con);
                comm.Parameters.AddWithValue("@t", trip);
                comm.Parameters.AddWithValue("@d", bookTrip.c_date);
                comm.Parameters.AddWithValue("@p", bookTrip.c_price);
                comm.Parameters.AddWithValue("@at", bookTrip.c_available_tickets - bookTrip.c_quantity);
                comm.Parameters.AddWithValue("@q", bookTrip.c_quantity);
                comm.Parameters.AddWithValue("@c", bookTrip.c_cost);
                comm.Parameters.AddWithValue("@s", "Scheduled");
                var userid = access.HttpContext.Session.GetInt32("userid") ?? 0;
                comm.Parameters.AddWithValue("@u", userid);
                comm.ExecuteNonQuery();

                string query2 = "update public.t_trip set c_current_stock = c_current_stock - @q where c_id= @t";
                comm = new NpgsqlCommand(query2, con);
                comm.Parameters.AddWithValue("@q", bookTrip.c_quantity);
                comm.Parameters.AddWithValue("@t", Convert.ToInt32(bookTrip.c_trip));
                comm.ExecuteNonQuery();

            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

    }
    public List<BookTrip> GetUserTrips()
    {
        List<BookTrip> bookings = new List<BookTrip>();
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {

                con.Open();
                string query = "select * from public.t_book_trip where c_status='Scheduled' and c_user_id=@userid";
                var command = new NpgsqlCommand(query, con);
                var userid = access.HttpContext.Session.GetInt32("userid") ?? 0;
                command.Parameters.AddWithValue("@userid", userid);
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    BookTrip bookTrip = new BookTrip();
                    bookTrip.c_id = reader.GetInt32(0);
                    bookTrip.c_trip = reader.GetString(1);
                    bookTrip.c_date = reader.GetDateTime(2);
                    bookTrip.c_price = reader.GetString(3);
                    bookTrip.c_available_tickets = reader.GetInt32(4);
                    bookTrip.c_quantity = reader.GetInt32(5);
                    bookTrip.c_cost = reader.GetInt32(6);
                    bookTrip.c_status = reader.GetString(7);
                    bookTrip.c_user_id = reader.GetInt32(8);
                    bookings.Add(bookTrip);
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

        return bookings;
    }

    public void CancelTrip(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "update t_book_trip set c_status = 'Cancelled' where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public List<BookTrip> GetBookingHistory()
    {
        List<BookTrip> bookings = new List<BookTrip>();
        try
        {
            var con = new NpgsqlConnection(conn);
            con.Open();
            string query = "select * from public.t_book_trip where c_user_id=@userid";
            var command = new NpgsqlCommand(query, con);
            var userid = access.HttpContext.Session.GetInt32("userid") ?? 0;
            command.Parameters.AddWithValue("@userid", userid);
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                BookTrip bookTrip = new BookTrip();
                bookTrip.c_id = reader.GetInt32(0);
                bookTrip.c_trip = reader.GetString(1);
                bookTrip.c_date = reader.GetDateTime(2);
                bookTrip.c_price = reader.GetString(3);
                bookTrip.c_available_tickets = reader.GetInt32(4);
                bookTrip.c_quantity = reader.GetInt32(5);
                bookTrip.c_cost = reader.GetInt32(6);
                bookTrip.c_status = reader.GetString(7);
                bookings.Add(bookTrip);
            }
            con.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

        return bookings;
    }

}