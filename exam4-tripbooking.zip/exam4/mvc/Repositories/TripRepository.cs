using mvc.Models;
using Npgsql;

namespace mvc.Repositories;
public class TripRepository
{
    private string conn;
    private IHttpContextAccessor access;
    public TripRepository(IConfiguration config, IHttpContextAccessor acces)
    {
        conn = config.GetConnectionString("a");
        access = acces;
    }

    public List<TripModel> GetTrips()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_trip,c_price,c_ticket_stock,c_current_stock from t_trip";
                var comm = new NpgsqlCommand(query, con);
                var reader = comm.ExecuteReader();
                var trips = new List<TripModel>();
                while (reader.Read())
                {
                    var trip = new TripModel
                    {
                        c_id = reader.GetInt32(0),
                        c_trip = reader.GetString(1),
                        c_price = reader.GetString(2),
                        c_ticket_stock = reader.GetInt32(3),
                        c_current_stock = reader.GetInt32(4),
                    };
                    trips.Add(trip);
                }
                return trips;
            }
        }
        catch (System.Exception e)
        {
            System.Console.WriteLine(e.Message);
            throw;
        }
        return null;
    }

    public void AddTrip(TripModel trip)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "insert into t_trip (c_trip,c_price,c_ticket_stock,c_current_stock) values(@t,@p,@s,@c)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@t", trip.c_trip);
                comm.Parameters.AddWithValue("@p", trip.c_price);
                comm.Parameters.AddWithValue("@s", trip.c_ticket_stock);
                comm.Parameters.AddWithValue("@c", trip.c_current_stock);
                comm.ExecuteNonQuery();
            }
        }
        catch (System.Exception e)
        {
            System.Console.WriteLine(e.Message);
            throw;
        }
    }

    public TripModel GetTripById(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_trip,c_price,c_ticket_stock,c_current_stock from t_trip where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var reader = comm.ExecuteReader();
                var trip = new TripModel();
                if (reader.Read())
                {
                    trip.c_id = reader.GetInt32(0);
                    trip.c_trip = reader.GetString(1);
                    trip.c_price = reader.GetString(2);
                    trip.c_ticket_stock = reader.GetInt32(3);
                    trip.c_current_stock = reader.GetInt32(4);
                    return trip;
                }
            }
        }
        catch (System.Exception e)
        {
            System.Console.WriteLine(e.Message);
            throw;
        }
        return null;
    }

    public void UpdateTrip(TripModel trip)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "update t_trip set c_trip = @t,c_price=@p,c_ticket_stock=@s,c_current_stock=@c where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@t", trip.c_trip);
                comm.Parameters.AddWithValue("@p", trip.c_price);
                comm.Parameters.AddWithValue("@s", trip.c_ticket_stock);
                comm.Parameters.AddWithValue("@c", trip.c_current_stock);
                comm.Parameters.AddWithValue("id", trip.c_id);
                comm.ExecuteNonQuery();
            }
        }
        catch (System.Exception e)
        {
            System.Console.WriteLine(e.Message);
            throw;
        }
    }
    public void DeleteTrip(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "delete from t_trip where c_id = @id";
                var comm = new NpgsqlCommand(query, con);

                comm.Parameters.AddWithValue("id", id);
                comm.ExecuteNonQuery();
            }
        }
        catch (System.Exception e)
        {
            System.Console.WriteLine(e.Message);
            throw;
        }
    }

    public void DeleteTrips(List<int> ids)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "delete from t_trip where c_id = any(@id)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", ids);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }
}