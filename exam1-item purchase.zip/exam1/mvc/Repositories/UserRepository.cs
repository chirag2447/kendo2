using mvc.Models;
using Npgsql;
namespace mvc.Repositories;
public class UserRepository
{
    private readonly string conn;
    private readonly IHttpContextAccessor httpContextAccessor;
    public UserRepository(IConfiguration config, IHttpContextAccessor access)
    {
        conn = config.GetConnectionString("con");
        httpContextAccessor = access;
    }

    public void Register(UserModel user)
    {
        try
        {

            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "Insert into t_usermaster (c_username,c_email,c_password,c_role) values (@name,@email,@password,@role)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@name", user.c_username);
                comm.Parameters.AddWithValue("@email", user.c_email);
                comm.Parameters.AddWithValue("@password", user.c_password);
                comm.Parameters.AddWithValue("@role", "admin");
                comm.ExecuteNonQuery();

            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public bool Login(UserModel user)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "Select c_id,c_username,c_email,c_password,c_role from t_usermaster where c_email=@email and c_password=@password";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@email", user.c_email);
                comm.Parameters.AddWithValue("@password", user.c_password);
                var reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    var username = reader.GetString(1);
                    var email = reader.GetString(2);
                    var role = reader.GetString(4);
                    httpContextAccessor.HttpContext.Session.SetString("username", username);
                    httpContextAccessor.HttpContext.Session.SetString("email", email);
                    httpContextAccessor.HttpContext.Session.SetString("role", role);
                    httpContextAccessor.HttpContext.Session.SetInt32("id", reader.GetInt32(0));
                    return true;
                }
                else
                {

                    return false;
                }
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return false;
    }

    public List<ItemModel> GetAllItems()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock from t_items";
                var comm = new NpgsqlCommand(query, con);
                var reader = comm.ExecuteReader();
                List<ItemModel> Items = new List<ItemModel>();
                while (reader.Read())
                {
                    var item = new ItemModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_category = reader.GetString(2),
                        c_image = reader.GetString(3),
                        c_cost_per_unit = reader.GetInt32(4),
                        c_initial_stock = reader.GetInt32(5),
                        c_available_stock = reader.GetInt32(6)
                    };

                    Items.Add(item);
                }
                return Items;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void AddItem(ItemModel item)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "insert into t_items(c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock)values(@name,@category,@image,@cost,@stock,@avail)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@name", item.c_name);
                comm.Parameters.AddWithValue("@category", item.c_category);
                comm.Parameters.AddWithValue("@image", item.c_image);
                comm.Parameters.AddWithValue("@cost", item.c_cost_per_unit);
                comm.Parameters.AddWithValue("@stock", item.c_initial_stock);
                comm.Parameters.AddWithValue("@avail", item.c_available_stock);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public ItemModel GetItemById(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock from t_items where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var reader = comm.ExecuteReader();
                var item = new ItemModel();
                while (reader.Read())
                {
                    item.c_id = reader.GetInt32(0);
                    item.c_name = reader.GetString(1);
                    item.c_category = reader.GetString(2);
                    item.c_image = reader.GetString(3);
                    item.c_cost_per_unit = reader.GetInt32(4);
                    item.c_initial_stock = reader.GetInt32(5);
                    item.c_available_stock = reader.GetInt32(6);
                }
                return item;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void UpdateItem(ItemModel item)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "update t_items set c_name=@name,c_category=@cat,c_image=@image,c_cost_per_unit=@cost,c_initial_stock=@stock,c_available_stock=@avail where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@name", item.c_name);
                comm.Parameters.AddWithValue("@cat", item.c_category);
                comm.Parameters.AddWithValue("@image", item.c_image);
                comm.Parameters.AddWithValue("@cost", item.c_cost_per_unit);
                comm.Parameters.AddWithValue("@stock", item.c_initial_stock);
                comm.Parameters.AddWithValue("@avail", item.c_available_stock);
                comm.Parameters.AddWithValue("@id", item.c_id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public void DeleteItem(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "Delete from t_items where c_id = @id";
                var comm = new NpgsqlCommand(query, con);

                comm.Parameters.AddWithValue("@id", id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }
}