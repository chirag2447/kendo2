using mvc.Models;
using Npgsql;

namespace mvc.Repositories;
public class CustomerRepository
{
    private readonly string conn;
    private readonly IHttpContextAccessor httpContextAccessor;
    public CustomerRepository(IConfiguration config, IHttpContextAccessor access)
    {
        conn = config.GetConnectionString("con");
        httpContextAccessor = access;
    }

    public List<ItemModel> GetAllItems()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock from t_items";
                var comm = new NpgsqlCommand(query, con);
                var reader = comm.ExecuteReader();
                List<ItemModel> Items = new List<ItemModel>();
                while (reader.Read())
                {
                    var item = new ItemModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_category = reader.GetString(2),
                        c_image = reader.GetString(3),
                        c_cost_per_unit = reader.GetInt32(4),
                        c_initial_stock = reader.GetInt32(5),
                        c_available_stock = reader.GetInt32(6)
                    };

                    Items.Add(item);
                }
                return Items;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public ItemModel GetItemById(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock from t_items where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var reader = comm.ExecuteReader();
                var item = new ItemModel();
                while (reader.Read())
                {
                    item.c_id = reader.GetInt32(0);
                    item.c_name = reader.GetString(1);
                    item.c_category = reader.GetString(2);
                    item.c_image = reader.GetString(3);
                    item.c_cost_per_unit = reader.GetInt32(4);
                    item.c_initial_stock = reader.GetInt32(5);
                    item.c_available_stock = reader.GetInt32(6);
                }
                return item;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }


    public List<ItemModel> GetItemByIds(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock from t_items where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var reader = comm.ExecuteReader();
                var item = new List<ItemModel>();
                while (reader.Read())
                {
                    var it = new ItemModel
                    {

                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_category = reader.GetString(2),
                        c_image = reader.GetString(3),
                        c_cost_per_unit = reader.GetInt32(4),
                        c_initial_stock = reader.GetInt32(5),
                        c_available_stock = reader.GetInt32(6),
                    };
                    item.Add(it);
                }
                return item;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }
    public void Purchase(PurchaseModel pur)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "insert into t_purchase(c_item_id,c_quantity,c_total_cost,c_cost_per_unit,c_user_id)values(@id,@q,@total,@cost,@user)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", pur.c_item_id);
                comm.Parameters.AddWithValue("@q", pur.c_quantity);
                comm.Parameters.AddWithValue("@total", pur.c_total_cost);
                comm.Parameters.AddWithValue("@cost", pur.c_cost_per_unit);
                var id = httpContextAccessor.HttpContext.Session.GetInt32("id");
                comm.Parameters.AddWithValue("@user", id);
                comm.ExecuteNonQuery();

                query = "update t_items set c_available_stock = c_available_stock - @q where c_id = @id";
                comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@q", pur.c_quantity);
                comm.Parameters.AddWithValue("@id", pur.c_item_id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {

        }
    }


}