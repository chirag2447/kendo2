namespace mvc.Models;
public class PurchaseModel
{
    public int c_id { get; set; }
    public int c_item_id { get; set; }
    public string c_item_name { get; set; }
    public int c_quantity { get; set; }
    public int c_total_cost { get; set; }
    public int c_cost_per_unit { get; set; }

}