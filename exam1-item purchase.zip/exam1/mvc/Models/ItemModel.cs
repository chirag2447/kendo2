namespace mvc.Models;
public class ItemModel
{
    public int c_id { get; set; }


    public string c_name { get; set; }


    public string c_category { get; set; }


    public string c_image { get; set; }


    public int c_cost_per_unit { get; set; }


    public int c_initial_stock { get; set; }


    public int c_available_stock { get; set; }

    public IFormFile Image { get; set; }
}