using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class UserController : Controller
{
    private readonly UserRepository userrepo;


    public UserController(UserRepository userr)
    {
        userrepo = userr;
    }

    public IActionResult Index()
    {
        var username = HttpContext.Session.GetString("username");
        var role = HttpContext.Session.GetString("role");
        if (username == null || role == "user")
        {
            return RedirectToAction("login");
        }
        var items = userrepo.GetAllItems();
        return View(items);
    }

    public IActionResult Indexk()
    {
        return View();
    }
    public IActionResult GetData()
    {
        var username = HttpContext.Session.GetString("username");
        var role = HttpContext.Session.GetString("role");
        if (username == null || role == "user")
        {
            return RedirectToAction("login");
        }
        var items = userrepo.GetAllItems();
        return Json(items);
    }

    public IActionResult Upload(IFormFile Image)
    {
        var filename = Image.FileName;
        var uniquename = Guid.NewGuid() + "_" + filename;
        var path = "wwwroot/images/" + uniquename;
        var reader = new FileStream(path, FileMode.Create);
        Image.CopyTo(reader);
        return Ok(new { fileName = uniquename });

    }

    [HttpPost]
    public IActionResult Addk(ItemModel item)
    {
        userrepo.AddItem(item);
        return Ok();
    }
    [HttpPost]
    public IActionResult Updatek(ItemModel item){
        userrepo.UpdateItem(item);
        return Ok();
    }

    public IActionResult Deletek(int id)
    {
        userrepo.DeleteItem(id);
        return Ok();
    }

    public IActionResult Add()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Add(ItemModel item)
    {
        var filename = item.Image.FileName;
        var uniquename = Guid.NewGuid() + "_" + filename;
        var path = "wwwroot/images/" + uniquename;
        var reader = new FileStream(path, FileMode.Create);
        item.Image.CopyTo(reader);
        item.c_image = uniquename;
        userrepo.AddItem(item);
        return RedirectToAction("index");
    }

    public IActionResult Update(int id)
    {
        var item = userrepo.GetItemById(id);
        return View(item);
    }

    [HttpPost]
    public IActionResult Update(ItemModel item)
    {
        if (item.Image == null)
        {
            var olditem = userrepo.GetItemById(item.c_id);
            item.c_image = olditem.c_image;
        }
        else
        {

            var filename = item.Image.FileName;
            var uniquename = Guid.NewGuid() + "_" + filename;
            var path = "wwwroot/images/" + uniquename;
            var reader = new FileStream(path, FileMode.Create);
            item.Image.CopyTo(reader);
            item.c_image = uniquename;
        }
        userrepo.UpdateItem(item);
        return RedirectToAction("index");
    }

    public IActionResult Delete(int id)
    {
        userrepo.DeleteItem(id);
        return RedirectToAction("index");
    }

    public IActionResult Register()
    {
        return View();
    }
    public IActionResult Registerk()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Register(UserModel user)
    {
        userrepo.Register(user);
        return RedirectToAction("login");
    }

    public IActionResult Login()
    {
        return View();
    }
    public IActionResult Logink()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(UserModel user)
    {
        var islogin = userrepo.Login(user);
        if (islogin)
        {
            if (HttpContext.Session.GetString("role") == "user")
                return RedirectToAction("index", "customer");
            else
                return RedirectToAction("index");
        }
        else
        {
            return Ok("username or password is wrong");
        }
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
