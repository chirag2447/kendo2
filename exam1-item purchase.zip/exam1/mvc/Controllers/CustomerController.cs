using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class CustomerController : Controller
{
    private readonly CustomerRepository custrepo;
    public CustomerController(CustomerRepository repo)
    {
        custrepo = repo;
    }

    public IActionResult Index()
    {
        var items = custrepo.GetAllItems();
        return View(items);
    }
    public IActionResult Indexk()
    {
        var items = custrepo.GetAllItems();
        return View(items);
    }

    public IActionResult Index2k()
    {
        var items = custrepo.GetAllItems();
        return View(items);
    }

    public IActionResult Purchasek(int id)
    {
        var item = custrepo.GetItemById(id);
        return View(item);
    }
    public IActionResult Index2()
    {
        var items = custrepo.GetAllItems();
        return View(items);
    }

    public IActionResult Purchase(int id){
        var item = custrepo.GetItemById(id);
        return View(item);
    }

    public IActionResult Privacy()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Payment(PurchaseModel pur){
        custrepo.Purchase(pur);
        return Ok();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
