using Npgsql;
using mvc.Models;
public class EmployeeRepository
{
    private readonly string connString;
    public EmployeeRepository(IConfiguration config)
    {
        connString = config.GetConnectionString("groupA");
    }

    public List<EmployeeModel> GetEmployees()
    {
        try
        {
            using (var con = new NpgsqlConnection(connString))
            {
                con.Open();
                var query = "select * from t_employeemaster";
                var commmand = new NpgsqlCommand(query, con);
                var reader = commmand.ExecuteReader();
                var employees = new List<EmployeeModel>();
                while (reader.Read())
                {
                    var employee = new EmployeeModel();
                    employee.c_id = reader.GetInt32(0);
                    employee.c_name = reader.GetString(1);
                    employee.c_gender = reader.GetString(2);
                    employee.c_dob = reader.GetDateTime(3);
                    employee.c_shift = (string[])reader["c_shift"];
                    employee.c_department = reader.GetInt32(5);
                    employee.c_image = reader.GetString(6);
                    employees.Add(employee);
                }
                return employees;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }
    public EmployeeModel GetEmployeeById(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(connString))
            {
                con.Open();
                var query = "select * from t_employeemaster where c_id=@id";
                var commmand = new NpgsqlCommand(query, con);
                commmand.Parameters.AddWithValue("@id", id);
                var reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    var employee = new EmployeeModel();
                    employee.c_id = reader.GetInt32(0);
                    employee.c_name = reader.GetString(1);
                    employee.c_gender = reader.GetString(2);
                    employee.c_dob = reader.GetDateTime(3);
                    employee.c_shift = (string[])reader["c_shift"];
                    employee.c_department = reader.GetInt32(5);
                    employee.c_image = reader.GetString(6);

                    return employee;
                }
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public EmployeeModel GetEmployeesFromId(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(connString))
            {
                con.Open();
                var query = "select c_image from t_employeemaster where c_id=@id";
                var commmand = new NpgsqlCommand(query, con);
                commmand.Parameters.AddWithValue("@id", id);
                var reader = commmand.ExecuteReader();
                if (reader.Read())
                {
                    var employee = new EmployeeModel();

                    employee.c_image = reader.GetString(0);
                    return employee;
                }
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }
    public void DeleteEmployee(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(connString))
            {
                con.Open();
                var query = "delete from t_employeemaster where c_id=@id";
                var commmand = new NpgsqlCommand(query, con);
                commmand.Parameters.AddWithValue("@id", id);
                commmand.ExecuteNonQuery();

            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public List<DeparmentModel> GetAllDepartments()
    {
        try
        {
            using (var con = new NpgsqlConnection(connString))
            {
                con.Open();
                var query = "select * from t_departments";
                var commmand = new NpgsqlCommand(query, con);
                var reader = commmand.ExecuteReader();
                var depts = new List<DeparmentModel>();
                while (reader.Read())
                {
                    var dep = new DeparmentModel();
                    dep.c_id = reader.GetInt32(0);
                    dep.c_name = reader.GetString(1);
                    depts.Add(dep);
                }
                return depts;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void AddEmployee(EmployeeModel emp)
    {
        using (var con = new NpgsqlConnection(connString))
        {
            con.Open();
            var query = "insert into t_employeemaster (c_name,c_gender,c_dob,c_shift,c_department,c_image) values(@n,@g,@d,@s,@de,@i)";
            var command = new NpgsqlCommand(query, con);
            command.Parameters.AddWithValue("@n", emp.c_name);
            command.Parameters.AddWithValue("@g", emp.c_gender);
            command.Parameters.AddWithValue("@d", emp.c_dob);
            command.Parameters.AddWithValue("@s", emp.c_shift);
            command.Parameters.AddWithValue("@de", emp.c_department);
            command.Parameters.AddWithValue("@i", emp.c_image);
            command.ExecuteNonQuery();


        }
    }

    public void UpdateEmployee(EmployeeModel emp)
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "update t_employeemaster set c_name=@name,c_gender=@gender,c_dob=@dob,c_shift=@shift,c_department=@dept,c_image=@image where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@name", emp.c_name);
            command.Parameters.AddWithValue("@gender", emp.c_gender);
            command.Parameters.AddWithValue("@dob", emp.c_dob);
            command.Parameters.AddWithValue("@shift", emp.c_shift);
            command.Parameters.AddWithValue("@dept", emp.c_department);
            command.Parameters.AddWithValue("@image", emp.c_image);
            command.Parameters.AddWithValue("@id", emp.c_id);
            command.ExecuteNonQuery();

        }
    }

}