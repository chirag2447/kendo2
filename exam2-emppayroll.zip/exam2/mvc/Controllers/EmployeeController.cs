using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class EmployeeController : Controller
{
    private readonly EmployeeRepository er;

    public EmployeeController(EmployeeRepository repo)
    {
        er = repo;
    }

    public IActionResult GetEmployees()
    {
        var emps = er.GetEmployees();
        return Json(emps);
    }

    public IActionResult GetDesignations()
    {
        var d = er.GetDesignations();
        return Json(d);
    }

    public IActionResult GridIndex()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Addk(EmployeeModel emp)
    {
        er.AddEmployee(emp);
        var success = true;
        return Ok(); // Include more details if necessary
    }
    [HttpPost]
    public IActionResult Updatek(EmployeeModel emp)
    {
        er.UpdateEmployee(emp);
        return Ok();
    }
    public IActionResult Deletek(int id)
    {
        er.DeleteEmployee(id);
        return Ok();
    }
    public IActionResult Index()
    {
        var employees = er.GetEmployees();
        return View(employees);
    }

    public IActionResult Add()
    {
        var designations = er.GetDesignations();
        ViewBag.designations = designations;
        return View();
    }

    [HttpPost]
    public IActionResult Add(EmployeeModel emp)
    {
        er.AddEmployee(emp);
        return RedirectToAction("index");
    }

    public IActionResult Update(int id)
    {
        var emp = er.GetEmpById(id);
        var designations = er.GetDesignations();
        ViewBag.designations = designations;
        return View(emp);
    }

    [HttpPost]
    public IActionResult Update(EmployeeModel emp)
    {
        er.UpdateEmployee(emp);
        return RedirectToAction("index");
    }

    public IActionResult Delete(int id)
    {
        er.DeleteEmployee(id);
        return RedirectToAction("index");
    }

    [HttpPost]
    public IActionResult Deletes(List<int> ids)
    {
        er.Deletes(ids);
        return Ok();
    }
    public IActionResult Payroll(int id)
    {
        var emp = er.GetEmpById(id);
        var gross = emp.c_gross_salary;
        var basic = gross * 60 / 100;
        var da = gross * 25 / 100;
        var hra = gross * 15 / 100;
        double tax = 0;
        if (gross > 25000)
        {
            tax = gross * 10 / 100;
        }
        var th = basic + da + hra - tax;

        emp.c_basic = basic;
        emp.c_da = da;
        emp.c_hra = hra;
        emp.c_taxablesalary = gross - tax;
        emp.c_tax = tax;
        emp.c_take_home = th;

        er.EmployeePayroll(emp);
        return View(emp);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
