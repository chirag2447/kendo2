using mvc.Models;
using Npgsql;

namespace mvc.Repositories;
public class UserRepository
{
    private readonly string conn;
    private readonly IHttpContextAccessor access;
    public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        access = accessor;
        conn = config.GetConnectionString("c");
    }

    public void Register(UserModel user)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "insert into t_usermaster(c_username,c_email,c_password,c_role) values(@u,@e,@p,'user')";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@u", user.c_username);
                comm.Parameters.AddWithValue("@e", user.c_email);
                comm.Parameters.AddWithValue("@p", user.c_password);
                comm.ExecuteNonQuery();

            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public bool Login(UserModel user){
        try{
            using(var con = new NpgsqlConnection(conn)){
                con.Open();
                var query = "select c_id,c_username,c_email,c_password from t_usermaster where c_email = @e and c_password=@p";
                var comm = new NpgsqlCommand(query,con);
                comm.Parameters.AddWithValue("@e",user.c_email);
                comm.Parameters.AddWithValue("@p",user.c_password);
                var reader = comm.ExecuteReader();
                if(reader.Read()){
                    var username = reader.GetString(1);
                    var email = reader.GetString(2);
                    access.HttpContext.Session.SetString("username",username);
                    access.HttpContext.Session.SetString("email",email);
                    return true;

                }else{
                    return false;
                }
            }
        }catch(Exception e){
            System.Console.WriteLine(e.Message);
        }
        return false;
    }
}