using mvc.Models;
using Npgsql;

namespace mvc.Repositories;
public class EmployeeRepository
{
    private readonly string conn;
    private readonly IHttpContextAccessor access;
    public EmployeeRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        access = accessor;
        conn = config.GetConnectionString("c");
    }

    public List<EmployeeModel> GetEmployees()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select e.c_id,e.c_name,e.c_hiredate,e.c_gross_salary,e.c_designation,d.c_name,e.c_gender from t_emp e inner join t_designation d on e.c_designation = d.c_id";
                var comm = new NpgsqlCommand(query, con);
                var reader = comm.ExecuteReader();
                var employees = new List<EmployeeModel>();
                while (reader.Read())
                {
                    var emp = new EmployeeModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),
                        c_hiredate = reader.GetDateTime(2),
                        c_gross_salary = reader.GetDouble(3),
                        c_designation = reader.GetInt32(4),
                        c_designationname = reader.GetString(5),
                        c_gender = reader.GetString(6)
                    };
                    employees.Add(emp);
                }
                return employees;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void AddEmployee(EmployeeModel emp)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "insert into t_emp(c_name,c_hiredate,c_gross_salary,c_designation,c_gender) values(@name,@hire,@gross,@desig,@gender)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@name", emp.c_name);
                comm.Parameters.AddWithValue("@hire", emp.c_hiredate);
                comm.Parameters.AddWithValue("@gross", emp.c_gross_salary);
                comm.Parameters.AddWithValue("@desig", emp.c_designation);
                comm.Parameters.AddWithValue("@gender", emp.c_gender);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public EmployeeModel GetEmpById(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id,c_name,c_hiredate,c_gross_salary,c_designation,c_gender from t_emp where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@id", id);
                var reader = comm.ExecuteReader();
                var employees = new EmployeeModel();
                if (reader.Read())
                {

                    employees.c_id = reader.GetInt32(0);
                    employees.c_name = reader.GetString(1);
                    employees.c_hiredate = reader.GetDateTime(2);
                    employees.c_gross_salary = reader.GetDouble(3);
                    employees.c_designation = reader.GetInt32(4);
                    employees.c_gender = reader.GetString(5);



                    return employees;
                }
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void UpdateEmployee(EmployeeModel emp)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "update t_emp set c_name=@name,c_hiredate=@hire,c_gross_salary=@gross,c_designation=@desig,c_gender=@gender where c_id = @id ";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@name", emp.c_name);
                comm.Parameters.AddWithValue("@hire", emp.c_hiredate);
                comm.Parameters.AddWithValue("@gross", emp.c_gross_salary);
                comm.Parameters.AddWithValue("@desig", emp.c_designation);
                comm.Parameters.AddWithValue("@gender", emp.c_gender);
                comm.Parameters.AddWithValue("@id", emp.c_id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public void DeleteEmployee(int id)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "delete from t_emp where c_id = @id ";
                var comm = new NpgsqlCommand(query, con);

                comm.Parameters.AddWithValue("@id", id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public List<DesignationModel> GetDesignations()
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "select c_id, c_name from t_designation";
                var comm = new NpgsqlCommand(query, con);
                var reader = comm.ExecuteReader();
                var designation = new List<DesignationModel>();
                while (reader.Read())
                {
                    var emp = new DesignationModel
                    {
                        c_id = reader.GetInt32(0),
                        c_name = reader.GetString(1),

                    };
                    designation.Add(emp);
                }
                return designation;
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        return null;
    }

    public void EmployeePayroll(EmployeeModel emp)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "update t_emp set c_basic=@basic,c_da=@da,c_hra=@hra,c_taxablesalary=@ts,c_tax=@t,c_take_home=@th where c_id = @id";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@basic", emp.c_basic);
                comm.Parameters.AddWithValue("@da", emp.c_da);
                comm.Parameters.AddWithValue("@hra", emp.c_hra);
                comm.Parameters.AddWithValue("@ts", emp.c_taxablesalary);
                comm.Parameters.AddWithValue("@t", emp.c_tax);
                comm.Parameters.AddWithValue("@th", emp.c_take_home);
                comm.Parameters.AddWithValue("@id", emp.c_id);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

    public void Deletes(List<int> ids)
    {
        try
        {
            using (var con = new NpgsqlConnection(conn))
            {
                con.Open();
                var query = "delete from t_emp where c_id = any(@ids)";
                var comm = new NpgsqlCommand(query, con);
                comm.Parameters.AddWithValue("@ids", ids);
                comm.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }

}