namespace mvc.Models;
public class EmployeeModel{
    public int c_id { get; set; }
    public string c_name { get; set; }
    public DateTime c_hiredate { get; set; }
    public double c_gross_salary { get; set; }
    public int c_designation { get; set; }
    public string c_gender { get; set; }
    public double c_basic { get; set; }
    public double c_da { get; set; }
    public double c_hra { get; set; }
    public double c_taxablesalary { get; set; }
    public double c_tax { get; set; }
    public double c_take_home { get; set; }
    public string c_designationname { get; set; }
    
}