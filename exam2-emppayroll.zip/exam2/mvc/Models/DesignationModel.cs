namespace mvc.Models;
public class DesignationModel{
    public int c_id { get; set; }
    public string c_name { get; set; }
}