namespace mvc.Models;
public class UserModel{
    public int c_id { get; set; }
    public string c_username { get; set; }
    public string c_email { get; set; }
    public string c_password { get; set; }
}